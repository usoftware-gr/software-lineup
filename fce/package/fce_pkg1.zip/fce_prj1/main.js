
window.addEventListener('scroll', () => {
    if (window.scrollY > 0) {
        up_btn.style.display = 'block';
        header.style = "margin: -8px;   padding: 7px 7px 7px 15px;   width: 100%;   position: fixed;   background:#eee;";
    } else {

        up_btn.style.display = 'none';
        header.style = "margin: -8px;   padding: 7px 7px 7px 15px;   width: 100%;   position: fixed;";
    }
  });


function menu_click()
{
    if(menu.style.display == "none"){
        menu.style.display = "block";
        menu.style.animation = "0.3s updown-anime";
    
      }
      else if(menu.style.display == "block"){
        menu.style.animation = "0.3s downup-anime";
    
        setTimeout(() => {
          menu.style.display = "none";
        }, 180);
    
      }
    

    
}



